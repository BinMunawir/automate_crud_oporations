interface InquiryModel {
userID?: string | null;
bookID?: string | null;
volumeID?: string | null;
chapterID?: string | null;
documentID?: string | null;
inquiryID?: string | null;
createdDate?: number | null;
modifiedDate?: number | null;
inquiry?: string | null;
response?: string | null;
status?: number | null;
}