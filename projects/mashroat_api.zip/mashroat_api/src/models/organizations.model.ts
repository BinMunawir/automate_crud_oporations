interface OrganizationModel {
organizationID?: string | null;
createdDate?: number | null;
arTitle?: string | null;
enTitle?: string | null;
code?: string | null;
email?: string | null;
domain?: string | null;
type?: string | null;
}