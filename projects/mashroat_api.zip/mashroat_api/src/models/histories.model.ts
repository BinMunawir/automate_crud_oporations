interface HistorieModel {
userID?: string | null;
historieID?: string | null;
createdDate?: number | null;
modifiedDate?: number | null;
actionType?: number | null;
actionDate?: number | null;
bookID?: string | null;
volumeID?: string | null;
chapterID?: string | null;
}