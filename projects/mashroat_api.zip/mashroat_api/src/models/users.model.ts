interface UserModel {
userID?: string | null;
createdDate?: number | null;
modifiedDate?: number | null;
organizationID?: string | null;
password?: string | null;
name?: string | null;
email?: string | null;
phone?: string | null;
status?: number | null;
type?: string | null;
}