interface AdminModel {
adminID?: string | null;
createdDate?: number | null;
modifiedDate?: number | null;
name?: string | null;
password?: string | null;
role?: string | null;
email?: string | null;
status?: number | null;
}