interface GlossaryModel {
glossaryID?: string | null;
createdDate?: number | null;
createdBy?: string | null;
modifiedDate?: number | null;
term?: string | null;
definition?: string | null;
}