interface VolumeModel {
bookID?: string | null;
volumeID?: string | null;
createdDate?: number | null;
createdBy?: string | null;
modifiedDate?: number | null;
modifiedBy?: string | null;
arTitle?: string | null;
enTitle?: string | null;
versionNumber?: number | null;
}