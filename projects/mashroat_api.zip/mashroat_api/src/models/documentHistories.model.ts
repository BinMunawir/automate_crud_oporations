interface DocumentHistorieModel {
userID?: string | null;
bookID?: string | null;
volumeID?: string | null;
chapterID?: string | null;
documentID?: string | null;
documentHistorieID?: string | null;
createdDate?: number | null;
modifiedDate?: number | null;
actionType?: number | null;
actionDate?: number | null;
ipAddress?: string | null;
}