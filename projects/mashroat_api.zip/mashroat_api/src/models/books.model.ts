interface BookModel {
bookID?: string | null;
createdDate?: number | null;
createdBy?: string | null;
modifiedDate?: number | null;
modifiedBy?: string | null;
arTitle?: string | null;
enTitle?: string | null;
code?: string | null;
versionNumber?: number | null;
video?: string | null;
}