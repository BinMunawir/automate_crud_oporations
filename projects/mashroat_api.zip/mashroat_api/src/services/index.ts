const sqlStorage = require('sql_storage_system')

export default {
    sqlStorage,
}